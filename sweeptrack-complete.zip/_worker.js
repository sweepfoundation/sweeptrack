// SweepTrack API, served by Cloudflare Pages advanced mode (_worker.js at the project root).
// Works with dashboard zip uploads, which do not compile a functions/ folder. Uses the existing D1 binding `DB` (database sweep-db).
// Tables used: users, sessions, login_attempts, records, record_items. No schema changes are made here.

const PLASTICS = ['PET', 'HDPE', 'PVC', 'LDPE', 'PP', 'PS', 'Other'];
const COOKIE = 'sweep_session';
const SESSION_MS = 30 * 24 * 3600 * 1000; // 30 days, extended with use
const ITER = 100000; // Workers cap PBKDF2 at 100000
const DIGEST_BY_LEN = { 20: 'SHA-1', 32: 'SHA-256', 48: 'SHA-384', 64: 'SHA-512' };
const enc = new TextEncoder();

class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
const fail = (status, message) => new HttpError(status, message);
const json = (data, status = 200, headers = {}) => new Response(JSON.stringify(data), {
  status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers },
});

// ---------- bytes and crypto ----------
const toHex = (u8) => [...u8].map((b) => b.toString(16).padStart(2, '0')).join('');
const fromHex = (s) => Uint8Array.from(s.match(/../g) || [], (h) => parseInt(h, 16));
const isHex = (s) => /^[0-9a-fA-F]+$/.test(s) && s.length % 2 === 0;
const isB64 = (s) => /^[A-Za-z0-9+/_-]+={0,2}$/.test(s);
function fromB64(s) {
  const t = s.replace(/-/g, '+').replace(/_/g, '/').replace(/=+$/, '');
  const bin = atob(t + '='.repeat((4 - (t.length % 4)) % 4));
  return Uint8Array.from(bin, (c) => c.charCodeAt(0));
}
const sha256Hex = async (str) => toHex(new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(str))));
const randomHex = (n) => toHex(crypto.getRandomValues(new Uint8Array(n)));
function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let d = 0; for (let i = 0; i < a.length; i++) d |= a[i] ^ b[i];
  return d === 0;
}
async function pbkdf2(secret, salt, iterations, hash, len) {
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), 'PBKDF2', false, ['deriveBits']);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations, hash }, key, len * 8));
}
// New secrets are stored as: salt "v2:<hex>", hash <hex>, PBKDF2 SHA-256, 100000 iterations.
async function makeSecret(secret) {
  const salt = randomHex(16);
  return { hash: toHex(await pbkdf2(secret, fromHex(salt), ITER, 'SHA-256', 32)), salt: 'v2:' + salt, iterations: ITER };
}
// Verifies new (v2) secrets exactly, and also reads secrets saved by the earlier version of the app
// (PBKDF2 with a hex, base64 or plain text salt) so existing accounts keep working.
async function verifySecret(secret, hashStr, saltStr, iterations) {
  try {
    hashStr = String(hashStr || ''); saltStr = String(saltStr || '');
    if (saltStr.startsWith('v2:')) {
      const d = await pbkdf2(secret, fromHex(saltStr.slice(3)), Number(iterations) || ITER, 'SHA-256', 32);
      return safeEqual(d, fromHex(hashStr));
    }
    let stored = null;
    if (isHex(hashStr) && DIGEST_BY_LEN[hashStr.length / 2]) stored = fromHex(hashStr);
    else if (isB64(hashStr)) { try { const b = fromB64(hashStr); if (DIGEST_BY_LEN[b.length]) stored = b; } catch {} }
    if (!stored) return false;
    const salts = [];
    if (isHex(saltStr)) salts.push(fromHex(saltStr));
    if (isB64(saltStr)) { try { salts.push(fromB64(saltStr)); } catch {} }
    salts.push(enc.encode(saltStr));
    const iter = Number(iterations) || ITER;
    for (const salt of salts) {
      const d = await pbkdf2(secret, salt, iter, DIGEST_BY_LEN[stored.length], stored.length);
      if (safeEqual(d, stored)) return true;
    }
  } catch {}
  return false;
}
const normAnswer = (a) => String(a || '').trim().toLowerCase();
async function verifyAnswer(user, answer) {
  const tries = [...new Set([normAnswer(answer), String(answer || '').trim(), String(answer || '')])];
  const v2 = String(user.answer_salt || '').startsWith('v2:');
  for (const t of v2 ? tries.slice(0, 1) : tries) if (t && await verifySecret(t, user.answer_hash, user.answer_salt, user.iterations)) return true;
  return false;
}

// ---------- small helpers ----------
const nowIso = () => new Date().toISOString();
const str = (v) => (typeof v === 'string' ? v : v == null ? '' : String(v));
function cookieOf(request, name) {
  const m = (request.headers.get('cookie') || '').split(/;\s*/).find((c) => c.startsWith(name + '='));
  return m ? m.slice(name.length + 1) : '';
}
const sessionCookie = (token, maxAge) => `${COOKIE}=${token}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${maxAge}`;
async function readJson(request) {
  const text = await request.text();
  if (text.length > 20000) throw fail(413, 'Request too large.');
  try { const v = JSON.parse(text || '{}'); if (v && typeof v === 'object' && !Array.isArray(v)) return v; } catch {}
  throw fail(400, 'Invalid request.');
}
function validDate(s) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [y, m, d] = s.split('-').map(Number), x = new Date(Date.UTC(y, m - 1, d));
  return x.getUTCFullYear() === y && x.getUTCMonth() === m - 1 && x.getUTCDate() === d;
}
function parseNaira(v) {
  const t = str(v).trim().replace(/,/g, '');
  if (!/^\d{1,10}(\.\d{1,2})?$/.test(t)) throw fail(400, 'Enter a valid amount in naira (up to 2 decimal places).');
  const [i, f = ''] = t.split('.'); return Number(i) * 100 + Number(f.padEnd(2, '0'));
}
function parseKg(v) {
  const t = str(v).trim().replace(/,/g, '');
  if (!/^\d{1,9}(\.\d{1,3})?$/.test(t)) throw fail(400, 'Enter a valid KG amount (up to 3 decimal places).');
  const [i, f = ''] = t.split('.'); return Number(i) * 1000 + Number(f.padEnd(3, '0'));
}
const fmtMilli = (m) => { const f = String(m % 1000).padStart(3, '0').replace(/0+$/, ''); return Math.floor(m / 1000) + (f ? '.' + f : ''); };
const fmtKobo = (k) => Math.floor(k / 100) + '.' + String(k % 100).padStart(2, '0');
const ratePerKg = (kgMilli, kobo) => (kgMilli > 0 && kobo > 0 ? Math.round(kobo * 1000 / kgMilli) : null);

// ---------- sessions and sign in limits ----------
async function createSession(env, userId) {
  const token = randomHex(32), now = nowIso();
  await env.DB.prepare('INSERT INTO sessions (token_hash, user_id, created_at, last_seen_at) VALUES (?, ?, ?, ?)')
    .bind(await sha256Hex(token), userId, now, now).run();
  if (Math.random() < 0.05) { // occasional cleanup of expired sessions
    await env.DB.prepare('DELETE FROM sessions WHERE last_seen_at < ?').bind(new Date(Date.now() - SESSION_MS).toISOString()).run().catch(() => {});
  }
  return token;
}
async function getSession(env, request) {
  const token = cookieOf(request, COOKIE);
  if (!/^[0-9a-f]{64}$/.test(token)) return null;
  const th = await sha256Hex(token);
  const s = await env.DB.prepare('SELECT s.user_id, s.created_at, s.last_seen_at, u.username FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?').bind(th).first();
  if (!s) return null;
  const seen = Date.parse(s.last_seen_at) || 0;
  if (Date.now() - seen > SESSION_MS) { await env.DB.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(th).run(); return null; }
  if (Date.now() - seen > 3600 * 1000) { // extend, at most once an hour
    s.last_seen_at = nowIso();
    await env.DB.prepare('UPDATE sessions SET last_seen_at = ? WHERE token_hash = ?').bind(s.last_seen_at, th).run();
  }
  return { ...s, token_hash: th, expires: new Date((Date.parse(s.last_seen_at) || Date.now()) + SESSION_MS).toISOString() };
}
const WINDOW = 900; // 15 minutes
async function throttleCheck(env, key, max) {
  const r = await env.DB.prepare('SELECT failures, window_start FROM login_attempts WHERE key = ?').bind(key).first();
  const now = Math.floor(Date.now() / 1000);
  if (r && now - r.window_start < WINDOW && r.failures >= max) throw fail(429, `Too many attempts. Try again in ${Math.ceil((WINDOW - (now - r.window_start)) / 60)} minutes.`);
}
async function throttleFail(env, key) {
  const now = Math.floor(Date.now() / 1000);
  await env.DB.prepare(`INSERT INTO login_attempts (key, failures, window_start) VALUES (?1, 1, ?2)
    ON CONFLICT(key) DO UPDATE SET
      failures = CASE WHEN ?2 - window_start >= ${WINDOW} THEN 1 ELSE failures + 1 END,
      window_start = CASE WHEN ?2 - window_start >= ${WINDOW} THEN ?2 ELSE window_start END`).bind(key, now).run();
}
const throttleClear = (env, key) => env.DB.prepare('DELETE FROM login_attempts WHERE key = ?').bind(key).run();
const ipOf = (request) => request.headers.get('CF-Connecting-IP') || 'unknown';

// ---------- account routes ----------
function checkNewPassword(p) { if (typeof p !== 'string' || p.length < 8) throw fail(400, 'Password must be at least 8 characters.'); if (p.length > 200) throw fail(400, 'Password is too long.'); }
function checkQuestion(q, a) {
  q = str(q).trim(); a = str(a);
  if (!q || q.length > 120) throw fail(400, 'Enter a security question (up to 120 characters).');
  if (normAnswer(a).length < 2 || a.length > 100) throw fail(400, 'Enter an answer to your security question.');
  return q;
}
async function userByName(env, username) {
  return env.DB.prepare('SELECT * FROM users WHERE username = ? COLLATE NOCASE').bind(str(username).trim()).first();
}
async function startSession(env, userId) {
  const token = await createSession(env, userId);
  return { 'set-cookie': sessionCookie(token, SESSION_MS / 1000) };
}

async function authRoutes(path, method, request, env) {
  if (path === '/api/auth/status' && method === 'GET') {
    const r = await env.DB.prepare('SELECT COUNT(*) AS n FROM users').first();
    return json({ setup_needed: !r || r.n === 0 });
  }
  if (path === '/api/signup' && method === 'POST') {
    const b = await readJson(request);
    const username = str(b.username).trim();
    if (!username || username.length > 64) throw fail(400, 'Enter a username (up to 64 characters).');
    checkNewPassword(b.password); const question = checkQuestion(b.question, b.answer);
    const pw = await makeSecret(b.password), an = await makeSecret(normAnswer(b.answer));
    const res = await env.DB.prepare(`INSERT INTO users (username, password_hash, salt, iterations, created_at, security_question, answer_hash, answer_salt)
      SELECT ?, ?, ?, ?, ?, ?, ?, ? WHERE NOT EXISTS (SELECT 1 FROM users)`)
      .bind(username, pw.hash, pw.salt, pw.iterations, nowIso(), question, an.hash, an.salt).run();
    if (!res.meta || res.meta.changes === 0) throw fail(403, 'Sign up is closed. Please sign in.');
    const u = await userByName(env, username);
    return json({ ok: true }, 200, await startSession(env, u.id));
  }
  if (path === '/api/login' && method === 'POST') {
    const b = await readJson(request), username = str(b.username).trim(), password = str(b.password);
    const k1 = 'login:' + username.toLowerCase(), k2 = 'login-ip:' + ipOf(request);
    await throttleCheck(env, k1, 10); await throttleCheck(env, k2, 40);
    const u = username && password ? await userByName(env, username) : null;
    if (!u || !(await verifySecret(password, u.password_hash, u.salt, u.iterations))) {
      await throttleFail(env, k1); await throttleFail(env, k2);
      throw fail(401, 'Wrong username or password.');
    }
    if (!String(u.salt).startsWith('v2:')) { // move an older stored password to the current format after a correct sign in
      const pw = await makeSecret(password);
      await env.DB.prepare('UPDATE users SET password_hash = ?, salt = ?, iterations = ? WHERE id = ?').bind(pw.hash, pw.salt, pw.iterations, u.id).run().catch(() => {});
    }
    await throttleClear(env, k1);
    return json({ ok: true }, 200, await startSession(env, u.id));
  }
  if (path === '/api/reset/question' && method === 'POST') {
    const b = await readJson(request), username = str(b.username).trim();
    await throttleCheck(env, 'reset-q:' + ipOf(request), 30);
    const u = username ? await userByName(env, username) : null;
    if (!u) { await throttleFail(env, 'reset-q:' + ipOf(request)); throw fail(404, 'No account found with that username.'); }
    if (!u.security_question || !u.answer_hash) throw fail(400, 'No security question is set for this account.');
    return json({ question: u.security_question });
  }
  if (path === '/api/reset' && method === 'POST') {
    const b = await readJson(request), username = str(b.username).trim(), key = 'reset:' + username.toLowerCase();
    await throttleCheck(env, key, 5);
    checkNewPassword(b.new_password);
    const u = username ? await userByName(env, username) : null;
    if (!u || !u.answer_hash || !(await verifyAnswer(u, b.answer))) { await throttleFail(env, key); throw fail(403, 'That answer is not correct.'); }
    const pw = await makeSecret(b.new_password);
    await env.DB.batch([
      env.DB.prepare('UPDATE users SET password_hash = ?, salt = ?, iterations = ? WHERE id = ?').bind(pw.hash, pw.salt, pw.iterations, u.id),
      env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(u.id),
    ]);
    await throttleClear(env, key); await throttleClear(env, 'login:' + username.toLowerCase());
    return json({ ok: true });
  }
  return null;
}

async function accountRoutes(path, method, request, env, session) {
  if (path === '/api/me' && method === 'GET') return json({ username: session.username, session_created: session.created_at, session_expires: session.expires });
  if (path === '/api/logout' && method === 'POST') {
    await env.DB.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(session.token_hash).run();
    return json({ ok: true }, 200, { 'set-cookie': sessionCookie('', 0) });
  }
  if (path === '/api/password' && method === 'POST') {
    const b = await readJson(request); checkNewPassword(b.new_password);
    const u = await env.DB.prepare('SELECT * FROM users WHERE id = ?').bind(session.user_id).first();
    const key = 'pw:' + session.user_id; await throttleCheck(env, key, 8);
    if (!(await verifySecret(str(b.current_password), u.password_hash, u.salt, u.iterations))) { await throttleFail(env, key); throw fail(403, 'Current password is incorrect.'); }
    const pw = await makeSecret(b.new_password);
    await env.DB.batch([
      env.DB.prepare('UPDATE users SET password_hash = ?, salt = ?, iterations = ? WHERE id = ?').bind(pw.hash, pw.salt, pw.iterations, u.id),
      env.DB.prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash != ?').bind(u.id, session.token_hash),
    ]);
    await throttleClear(env, key);
    return json({ ok: true });
  }
  if (path === '/api/security' && method === 'POST') {
    const b = await readJson(request), question = checkQuestion(b.question, b.answer);
    const u = await env.DB.prepare('SELECT * FROM users WHERE id = ?').bind(session.user_id).first();
    const key = 'pw:' + session.user_id; await throttleCheck(env, key, 8);
    if (!(await verifySecret(str(b.current_password), u.password_hash, u.salt, u.iterations))) { await throttleFail(env, key); throw fail(403, 'Current password is incorrect.'); }
    const an = await makeSecret(normAnswer(b.answer));
    await env.DB.prepare('UPDATE users SET security_question = ?, answer_hash = ?, answer_salt = ? WHERE id = ?').bind(question, an.hash, an.salt, u.id).run();
    await throttleClear(env, key);
    return json({ ok: true });
  }
  return null;
}

// ---------- records ----------
function filters(url) {
  const where = [], args = [];
  const from = url.searchParams.get('from'), to = url.searchParams.get('to'), q = (url.searchParams.get('q') || '').trim().slice(0, 120);
  if (from) { if (!validDate(from)) throw fail(400, 'Invalid start date.'); where.push('date >= ?'); args.push(from); }
  if (to) { if (!validDate(to)) throw fail(400, 'Invalid end date.'); where.push('date <= ?'); args.push(to); }
  if (q) { where.push("customer_name LIKE ? ESCAPE '\\'"); args.push('%' + q.replace(/[\\%_]/g, (c) => '\\' + c) + '%'); }
  return { where, args };
}
async function attachItems(env, rows) {
  const items = new Map(rows.map((r) => [r.id, []]));
  if (rows.length) {
    const { results } = await env.DB.prepare(`SELECT record_id, plastic_type, kg_milli FROM record_items WHERE record_id IN (${rows.map(() => '?').join(',')})`).bind(...rows.map((r) => r.id)).all();
    for (const it of results || []) items.get(it.record_id)?.push({ type: it.plastic_type, kg_milli: it.kg_milli });
    for (const list of items.values()) list.sort((a, b) => PLASTICS.indexOf(a.type) - PLASTICS.indexOf(b.type));
  }
  return rows.map((r) => ({
    id: r.id, date: r.date, customer_name: r.customer_name, address: r.address || '', phone: r.phone || '',
    kg_milli: r.kg_milli, amount_kobo: r.amount_kobo, remark: r.remark || '', items: items.get(r.id) || [],
    created_at: r.created_at, updated_at: r.updated_at,
  }));
}
async function getRecord(env, where, arg) {
  const row = await env.DB.prepare(`SELECT * FROM records WHERE ${where}`).bind(arg).first();
  return row ? (await attachItems(env, [row]))[0] : null;
}
function parseRecordBody(b) {
  const date = str(b.date).trim(); if (!validDate(date)) throw fail(400, 'Enter a valid date.');
  const customer_name = str(b.customer_name).trim(); if (!customer_name || customer_name.length > 120) throw fail(400, 'Enter the customer name (up to 120 characters).');
  const address = str(b.address).trim(); if (address.length > 300) throw fail(400, 'Address is too long (300 characters at most).');
  const phone = str(b.phone).trim();
  if (phone.length > 30) throw fail(400, 'Phone No is too long (30 characters at most).');
  if (phone && !/^[0-9+()\-\s./]+$/.test(phone)) throw fail(400, 'Phone No can only contain digits, spaces and + ( ) - . /');
  const remark = str(b.remark).trim(); if (remark.length > 500) throw fail(400, 'Remark is too long (500 characters at most).');
  const amount_kobo = parseNaira(b.amount);
  const items = [];
  if (b.items != null && !Array.isArray(b.items)) throw fail(400, 'Invalid plastic types.');
  for (const it of b.items || []) {
    const type = str(it && it.type);
    if (!PLASTICS.includes(type)) throw fail(400, 'Unknown plastic type.');
    if (items.some((x) => x.type === type)) throw fail(400, `${type} was added twice.`);
    const kg_milli = parseKg(it.kg); if (kg_milli <= 0) throw fail(400, `Enter a KG amount above zero for ${type}.`);
    items.push({ type, kg_milli });
  }
  let kg_milli;
  if (items.length) kg_milli = items.reduce((s, i) => s + i.kg_milli, 0);
  else if (b.kg != null && str(b.kg).trim() !== '') kg_milli = parseKg(b.kg);
  else throw fail(400, 'Select at least one plastic type.');
  return { date, customer_name, address: address || null, phone: phone || null, remark, amount_kobo, items, kg_milli };
}

async function recordRoutes(path, method, request, env) {
  const url = new URL(request.url);
  if (path === '/api/summary' && method === 'GET') {
    const { where, args } = filters(url);
    const r = await env.DB.prepare(`SELECT COUNT(*) AS c, COALESCE(SUM(kg_milli),0) AS kg, COALESCE(SUM(amount_kobo),0) AS amt,
      COALESCE(SUM(CASE WHEN remark LIKE '%pending%' THEN 1 ELSE 0 END),0) AS p FROM records ${where.length ? 'WHERE ' + where.join(' AND ') : ''}`).bind(...args).first();
    return json({ count: r.c, kg_milli: r.kg, amount_kobo: r.amt, pending: r.p });
  }
  if (path === '/api/records' && method === 'GET') {
    const { where, args } = filters(url);
    const limit = Math.min(Math.max(parseInt(url.searchParams.get('limit'), 10) || 10, 1), 50);
    const cur = url.searchParams.get('cursor');
    if (cur) {
      const m = /^(\d{4}-\d{2}-\d{2})\|(\d+)$/.exec(cur); if (!m) throw fail(400, 'Invalid cursor.');
      where.push('(date < ? OR (date = ? AND id < ?))'); args.push(m[1], m[1], Number(m[2]));
    }
    const { results } = await env.DB.prepare(`SELECT * FROM records ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY date DESC, id DESC LIMIT ?`).bind(...args, limit + 1).all();
    const more = results.length > limit, page = results.slice(0, limit);
    return json({ records: await attachItems(env, page), next_cursor: more ? `${page[page.length - 1].date}|${page[page.length - 1].id}` : null });
  }
  if (path === '/api/records' && method === 'POST') {
    const b = await readJson(request), rec = parseRecordBody(b);
    const cid = /^[\w-]{8,64}$/.test(str(b.client_id)) ? b.client_id : crypto.randomUUID();
    const dup = await getRecord(env, 'client_id = ?', cid); // a repeated submit returns the first save instead of a duplicate
    if (dup) return json({ ok: true, record: dup });
    const now = nowIso();
    await env.DB.batch([
      env.DB.prepare('INSERT INTO records (client_id, date, customer_name, address, phone, kg_milli, amount_kobo, remark, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
        .bind(cid, rec.date, rec.customer_name, rec.address, rec.phone, rec.kg_milli, rec.amount_kobo, rec.remark, now, now),
      ...rec.items.map((i) => env.DB.prepare('INSERT INTO record_items (record_id, plastic_type, kg_milli) VALUES ((SELECT id FROM records WHERE client_id = ?), ?, ?)').bind(cid, i.type, i.kg_milli)),
    ]);
    return json({ ok: true, record: await getRecord(env, 'client_id = ?', cid) }, 201);
  }
  const m = /^\/api\/records\/(\d+)$/.exec(path);
  if (m && (method === 'PUT' || method === 'DELETE')) {
    const id = Number(m[1]);
    if (!(await env.DB.prepare('SELECT id FROM records WHERE id = ?').bind(id).first())) throw fail(404, 'Record not found. It may already be deleted.');
    if (method === 'DELETE') {
      await env.DB.batch([env.DB.prepare('DELETE FROM record_items WHERE record_id = ?').bind(id), env.DB.prepare('DELETE FROM records WHERE id = ?').bind(id)]);
      return json({ ok: true });
    }
    const rec = parseRecordBody(await readJson(request));
    await env.DB.batch([
      env.DB.prepare('UPDATE records SET date = ?, customer_name = ?, address = ?, phone = ?, kg_milli = ?, amount_kobo = ?, remark = ?, updated_at = ? WHERE id = ?')
        .bind(rec.date, rec.customer_name, rec.address, rec.phone, rec.kg_milli, rec.amount_kobo, rec.remark, nowIso(), id),
      env.DB.prepare('DELETE FROM record_items WHERE record_id = ?').bind(id),
      ...rec.items.map((i) => env.DB.prepare('INSERT INTO record_items (record_id, plastic_type, kg_milli) VALUES (?, ?, ?)').bind(id, i.type, i.kg_milli)),
    ]);
    return json({ ok: true, record: await getRecord(env, 'id = ?', id) });
  }
  if (path === '/api/export' && method === 'GET') return exportCsv(url, env);
  return null;
}

// ---------- CSV export ----------
function cell(v) {
  let s = v == null ? '' : String(v);
  // spreadsheet formula safety: text that starts like a formula is neutralised, plain phone numbers like +234... are left alone
  if (/^[=@\t\r]/.test(s) || (/^[+\-]/.test(s) && !/^[+\-]?[\d\s().\-/]+$/.test(s))) s = "'" + s;
  return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}
async function exportCsv(url, env) {
  const { where, args } = filters(url);
  const head = ['Date', 'Customer Name', 'Phone No', 'Address', 'Plastic Types', ...PLASTICS.map((p) => p + ' KG'), 'Total KG', 'Amount (NGN)', 'Price per KG (NGN, overall)', 'Remark', 'Created', 'Updated'];
  const lines = [head.map(cell).join(',')];
  let cursor = null;
  for (;;) {
    const w = [...where], a = [...args];
    if (cursor) { w.push('(date < ? OR (date = ? AND id < ?))'); a.push(cursor.date, cursor.date, cursor.id); }
    const { results } = await env.DB.prepare(`SELECT * FROM records ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY date DESC, id DESC LIMIT 500`).bind(...a).all();
    if (!results.length) break;
    for (const r of await attachItems(env, results)) {
      const by = Object.fromEntries(r.items.map((i) => [i.type, i.kg_milli])), rate = ratePerKg(r.kg_milli, r.amount_kobo);
      lines.push([r.date, r.customer_name, r.phone, r.address, r.items.map((i) => i.type).join('; '),
        ...PLASTICS.map((p) => (by[p] != null ? fmtMilli(by[p]) : '')), fmtMilli(r.kg_milli), fmtKobo(r.amount_kobo),
        rate == null ? '' : fmtKobo(rate), r.remark, r.created_at, r.updated_at].map(cell).join(','));
    }
    if (results.length < 500) break;
    cursor = { date: results[results.length - 1].date, id: results[results.length - 1].id };
  }
  return new Response('\uFEFF' + lines.join('\r\n') + '\r\n', {
    headers: { 'content-type': 'text/csv; charset=utf-8', 'cache-control': 'no-store', 'content-disposition': `attachment; filename="sweep-records-${new Date().toISOString().slice(0, 10)}.csv"` },
  });
}

// ---------- entry point ----------
async function handleApi({ request, env }) {
  try {
    if (!env.DB) throw fail(500, 'Database is not connected. Check the DB binding.');
    const path = new URL(request.url).pathname.replace(/\/+$/, ''), method = request.method;
    if (method !== 'GET' && request.headers.get('X-Requested-With') !== 'sweep') throw fail(403, 'Request blocked.');
    let res = await authRoutes(path, method, request, env);
    if (res) return res;
    const session = await getSession(env, request);
    if (!session) throw fail(401, 'Please sign in.');
    res = (await accountRoutes(path, method, request, env, session)) || (await recordRoutes(path, method, request, env));
    if (res) return res;
    throw fail(404, 'Not found.');
  } catch (e) {
    if (e instanceof HttpError) return json({ error: e.message }, e.status);
    console.error('SweepTrack API error:', e && e.stack || e);
    return json({ error: 'Server error. Nothing was changed.' }, 500);
  }
}

export default {
  async fetch(request, env) {
    const path = new URL(request.url).pathname;
    if (path === '/api' || path.startsWith('/api/')) return handleApi({ request, env });
    return env.ASSETS.fetch(request); // everything else is the normal static app
  },
};
